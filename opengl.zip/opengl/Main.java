package com.caibi.opengl;

import com.caibi.opengl.Models.*;
import com.caibi.opengl.RenderEngine.*;
import org.lwjgl.opengl.*;

public class Main {
    public static void main(String[] args) {
        Window window = new Window();
        window.createWindow(1280, 720, "Test Window");

        Renderer renderer = new Renderer();

        float[] vertices = {
                0, 0.75f, 0,
                -0.75f, -0.5f, 0,
                0.75f, -0.5f, 0,
        };

        int[] indices = {
                0,1,2
        };

        Vao vao = new Vao();
        vao.bind();
        vao.createFloatAttribute(0, vertices, 3);
        vao.createIndexBuffer(indices);
        vao.unbind();

        while (!window.shouldClose()){
            renderer.renderVao(vao);
            window.updateWindow();
        }
        window.closeWindow();
    }
}
