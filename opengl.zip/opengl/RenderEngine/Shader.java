package com.caibi.opengl.RenderEngine;

import org.lwjgl.opengl.*;

import java.io.*;

public class Shader {
    private final int programID;

    public Shader(String vertShader, String fragShader){
        int vertexShader = loadShader(vertShader, 0x8B31);
        int fragmentShader = loadShader(fragShader, 0x8B30);

        programID = GL20.glCreateProgram();
        GL20.glAttachShader(programID, vertexShader);
        GL20.glAttachShader(programID, fragmentShader);
        GL20.glLinkProgram(programID);
        GL20.glValidateProgram(programID);
    }

    public void useProgram(){
        GL20.glUseProgram(programID);
    }

    public void stopProgram(){
        GL20.glUseProgram(0);
    }

    public void deleteProgram(){
        GL20.glDeleteProgram(programID);
    }

    private static int loadShader(String file, int type){
        StringBuilder builder = new StringBuilder();

        try{
            InputStream in = Shader.class.getResourceAsStream(file);
            InputStreamReader reader = new InputStreamReader(in);
            BufferedReader br = new BufferedReader(reader);
            String line;

            while ((line = br.readLine()) != null){
                builder.append(line).append("//\n");
            }
        }catch (IOException e){
            e.printStackTrace();
            System.exit(-1);
        }

        int shaderID = GL20.glCreateShader(type);
        GL20.glShaderSource(shaderID, builder);
        GL20.glCompileShader(shaderID);

        if ((GL20.glGetShaderi(shaderID, 0x8B81)) == 0){
            System.out.println(GL20.glGetShaderInfoLog(shaderID, 1000));
            System.exit(-1);
        }

        return shaderID;
    }
}
