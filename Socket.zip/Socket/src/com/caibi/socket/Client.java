package com.caibi.socket;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client{
    public Client(String target, int port){
        Socket s;
        try {
            s = new Socket(target, port);

            while (!s.isClosed()) {
                String text = input();
                if (!text.isEmpty()) {
                    PrintWriter pw = new PrintWriter(s.getOutputStream());
                    pw.println(text);
                    pw.flush();
                } else {
                    System.out.println("消息不能为空");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String input() {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }
}
