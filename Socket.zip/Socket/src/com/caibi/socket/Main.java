package com.caibi.socket;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Server th = new Server();
        th.start();

        System.out.println("输入你要连接的IP:");
        new Client(input(),4999);
    }

    public static String input() {
        Scanner scanner = new Scanner(System.in);
        return scanner.nextLine();
    }
}
