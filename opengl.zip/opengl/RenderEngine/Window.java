package com.caibi.opengl.RenderEngine;

import org.lwjgl.opengl.*;
import org.lwjgl.glfw.*;

public class Window {

    public long windowID;

    public void createWindow(int width, int height, String title){
        boolean initState = GLFW.glfwInit();

        if (!initState){
            throw new IllegalStateException("Could not create GLFW");
        }

        windowID = GLFW.glfwCreateWindow(width, height, title, 0L, 0L);

        if (windowID == 0L){
            throw new IllegalStateException("Could not create window");
        }

        GLFW.glfwMakeContextCurrent(windowID);
        GLFW.glfwSwapInterval(1);
        GLFW.glfwShowWindow(windowID);
        GL.createCapabilities();
    }

    public void updateWindow(){
        GLFW.glfwSwapBuffers(windowID);
        GLFW.glfwPollEvents();
        GLFW.glfwSwapInterval(1);
    }

    public void closeWindow(){
        GLFW.glfwDestroyWindow(windowID);
        GLFW.glfwTerminate();
    }

    public boolean shouldClose(){
        return GLFW.glfwWindowShouldClose(windowID);
    }

}
