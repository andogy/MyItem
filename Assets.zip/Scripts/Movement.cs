using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{

    public CharacterController cc;
    public float JH;
    public float speed = 15f;
    public float gravity = -30;
    Vector3 velocity;
    public float groundDis = 0.4f;
    public LayerMask ground;
    public Transform gc;
    bool isGround;

    void Update()
    {
        isGround = Physics.CheckSphere(gc.position, groundDis, ground);
        if (isGround && velocity.y < 0){
            velocity.y = -2f;
        }

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

           Vector3 move = transform.right * x + transform.forward * z;

        cc.Move(move * speed * Time.deltaTime);

        if (Input.GetButtonDown("Jump") && isGround){
            velocity.y = Mathf.Sqrt(JH * -2f * gravity);
        }

        velocity.y += gravity * Time.deltaTime;
        cc.Move(velocity * Time.deltaTime);
    }
}
