package com.caibi.qq;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.regex.*;

public class Main {
    public static String QRSig = null;
    public static JFrame frame;
    public static boolean getData = false;

    public static String name;
    public static String uin;
    public static String skey;
    public static String pskey;

    public static void main(String[] args) throws InterruptedException {
        isConnect();
        System.out.println(date() + "联网状态验证成功");
        getQRCode();
        System.out.println(date() + "关闭二维码视窗将会退出进程，验证成功后自动关闭弹窗");
        Thread.sleep(5000);
        getData();
        frame.dispose();
        System.out.println(date()+"名称: "+name);
        System.out.println(date()+"QQ号: "+uin);
        System.out.println(date()+"Skey: "+skey);
        System.out.println(date()+"pSkey: "+pskey);
    }

    public static String date(){
        Date dNow = new Date();
        SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd hh:mm:ss.SSS");

        return "[" + ft.format(dNow) + "] ";
    }

    public static void getQRCode(){
        Random rand = new Random();
        int random = rand.nextInt(999999999);
        if (random < 100000000){
            random+=100000000;
        }
        String html = "https://ssl.ptlogin2.qq.com/ptqrshow?appid=716027609&e=2&l=M&s=3&d=72&v=4&t=0.71500273" + random + "&daid=383&pt_3rd_aid=101487368";
        System.out.println(date() + "验证随机数: \""+ random + "\" 二维码图片: \"" + html + "\"");
        downloadFile(html, "qrc.png", true);
        showImage("qrc.png", "扫码验证");
    }

    /* public static String getHtmlContent(URL url, String encode) {
        StringBuilder contentBuffer = new StringBuilder();

        int responseCode;
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) url.openConnection();
            con.setRequestProperty("User-Agent", "n Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36");
            con.setConnectTimeout(60000);
            con.setReadTimeout(60000);
            responseCode = con.getResponseCode();
            if (responseCode == -1) {
                String re = url + " : connection is failure...";
                con.disconnect();
                return re;
            }
            if (responseCode >= 400)
            {
                String re = date() + "请求失败:get response code: " + responseCode;
                con.disconnect();
                return re;
            }

            InputStream inStr = con.getInputStream();
            InputStreamReader istreamReader = new InputStreamReader(inStr, encode);
            BufferedReader buffStr = new BufferedReader(istreamReader);

            String str;
            while ((str = buffStr.readLine()) != null)
                contentBuffer.append(str);
            inStr.close();
        } catch (IOException e) {
            e.printStackTrace();
            contentBuffer = null;
            System.out.println(date()+"error: " + url);
        } finally {
            assert con != null;
            con.disconnect();
        }
        assert contentBuffer != null;
        return contentBuffer.toString();
    }

    public static String getHtmlContent(String url, String encode) {
        try {
            URL rUrl = new URL(url);
            return getHtmlContent(rUrl, encode);
        } catch (Exception e) {
            e.printStackTrace();
            return date()+"网址错误！";
        }
    } */
    public static void downloadFile(String url, String filename, boolean qrsig) {
        String cookieValue;
        try {
            URL web = new URL(url);
            URLConnection conn;
            conn = web.openConnection();
            InputStream inputStream = conn.getInputStream();
            FileOutputStream outputStream = new FileOutputStream(filename);
            int bytesRead;
            byte[] buffer = new byte[435];
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            outputStream.close();
            inputStream.close();
            if (qrsig) {
                Map<String, List<String>> headerFields = conn.getHeaderFields();
                Set<String> headerFieldsSet = headerFields.keySet();
                for (String headerFieldKey : headerFieldsSet) {
                    if ("Set-Cookie".equalsIgnoreCase(headerFieldKey)) {
                        List<String> headerFieldValue = headerFields.get(headerFieldKey);
                        for (String headerValue : headerFieldValue) {
                            System.out.println(date() + "找到Cookie，正在获取qr-sig");
                            String[] fields = headerValue.split(";\s*");
                            cookieValue = fields[0];
                            System.out.println(date() + "Cookie: " + cookieValue);
                            String pattern = "qrsig=(.+)";
                            Pattern r = Pattern.compile(pattern);
                            Matcher match = r.matcher(cookieValue);
                            if (match.find()) {
                                System.out.println(date() + "QRSig: " + match.group(1) + "\n\n---主程序运行日志---");
                                QRSig = match.group(1);
                            }
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void showImage(String filepath, String title) {
        BufferedImage img;
        try {
            img = ImageIO.read(new File(filepath));
            ImageIcon icon = new ImageIcon(img);
            frame = new JFrame();
            frame.setLayout(new FlowLayout());
            frame.setSize(200, 200);
            frame.setLocationRelativeTo(null);
            frame.setTitle(title);
            JLabel lbl = new JLabel();
            lbl.setIcon(icon);
            frame.add(lbl);
            frame.setVisible(true);
            frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            frame.setResizable(false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getSIG(String text)
    {
        int hash = 0;

        for (int i = 0, len = text.length(); i < len; ++i)
            hash += (hash << 5) + (int)text.charAt(i);
        return String.valueOf(hash & 2147483647);
    }

    public static void getData() throws InterruptedException {
        while (!getData) {
            String token = getSIG(QRSig);
            long Timestamp = new Date().getTime();
            String backData = connectWeb("https://ssl.ptlogin2.qq.com/ptqrlogin?u1=https://qun.qq.com/&ptqrtoken=" + token + "&ptredirect=0&h=1&t=1&g=l&from_ui=1&ptlang=2052&action=0-0-" + Timestamp + "0000&js_ver=20010217&js_type=1&login_sig=&pt_uistyle=40&aid=716027609&daid=73&pt_3rd_aid=101487368");
            System.out.println(backData);
            int status = Integer.parseInt(getMiddle(backData, "ptuiCB('", "','"));
            int waitTime = 0;
            switch (status) {
                case (66) -> waitTime = 2000;
                case (67) -> waitTime = 100;
                case (68) -> {
                    System.out.println(date() + "本次登陆被拒绝");
                    System.exit(151);
                }
                case (65) -> {
                    System.out.println(date() + "二维码已失效");
                    System.exit(152);
                }
                case (0) -> {
                    System.out.println(date() + "登陆成功！");
                    //noinspection ConstantConditions
                    waitTime = 0;
                    getData = true;
                    String url = getMiddle(backData,"ptuiCB('0','0','","',");
                    System.out.println(date()+"登录链接: "+url);
                    name = getMiddle(backData,"','登录成功！', '","')");
                    uin = getMiddle(url,"uin=","&");
                    skey = getMiddle(backData,"skey=",";");
                    pskey = getMiddle(backData,"p_skey=",";");
                }
            }
            Thread.sleep(waitTime);
        }
    }

    public static void isConnect() {
        Runtime runtime = Runtime.getRuntime();
        try {
            Process process = runtime.exec("ping " + "www.baidu.com");
            InputStream is = process.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);
            String line;
            StringBuilder sb = new StringBuilder();
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            is.close();
            isr.close();
            br.close();

            if (!sb.toString().equals("")) {
                if (!(sb.toString().indexOf("TTL") > 0)){
                    System.out.println(date() + "网络异常，请检查网络设置后重新开启进程");
                    System.exit(150);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String connectWeb(String url){
        StringBuilder bs = null;
        URL urla;
        try {
            urla = new URL(url);
            HttpURLConnection urlcon = (HttpURLConnection) urla.openConnection();
            urlcon.setRequestProperty("Cookie", "qrsig="+QRSig+";");
            urlcon.connect();
            InputStream is = urlcon.getInputStream();
            BufferedReader buffer = new BufferedReader(new InputStreamReader(is));
            bs = new StringBuilder();
            String l;
            while ((l = buffer.readLine()) != null) {
                bs.append(l);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        assert bs != null;
        return bs.toString();
    }

    public static String getMiddle(String text, String left, String right){
        String result;
        int zLen;
        if (left == null || left.isEmpty()) {
            zLen = 0;
        } else {
            zLen = text.indexOf(left);
            if (zLen > -1) {
                zLen += left.length();
            } else {
                zLen = 0;
            }
        }
        int yLen = text.indexOf(right, zLen);
        if (yLen < 0 || right.isEmpty()) {
            yLen = text.length();
        }
        result = text.substring(zLen, yLen);
        return result;
    }
}
