package com.caibi.opengl.RenderEngine;

import com.caibi.opengl.Models.*;
import org.lwjgl.glfw.*;
import org.lwjgl.opengl.*;

public class Renderer {
    private final RenderShaders shaders;

    public Renderer(){
        shaders = new RenderShaders();
    }

    private void prepare(){
        GL11.glClear(0x4000);
        GL11.glClearColor(0.3f,0.725f,0.953f,1f);
    }

    public void renderVao(Vao vao){
        prepare();
        shaders.useProgram();
        vao.render();
        shaders.stopProgram();
    }
}
