using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Mirror;

public class Autojoin : MonoBehaviour
{

    [SerializeField] NetworkManager networkManager;

    // Start is called before the first frame update
    void Start()
    {
        networkManager.networkAddress = "219.76.29.91";
        networkManager.StartClient();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
