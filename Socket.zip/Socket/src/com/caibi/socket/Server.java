package com.caibi.socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread {
    @Override
    public void run() {
        ServerSocket ss;
        Socket s;
        try {
            ss = new ServerSocket(4999);
            s = ss.accept();
            System.out.println("Client Connect\n------------");

            while (s.isConnected()) {
                InputStreamReader isr = new InputStreamReader(s.getInputStream());
                BufferedReader br = new BufferedReader(isr);

                System.out.println("Client: " + br.readLine());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
