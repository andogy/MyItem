using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Look : MonoBehaviour
{

    public float mouseSent = 100f;
    public Transform body;
    float xRote = 0f;
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        float mouseX = Input.GetAxis("Mouse X") * mouseSent * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * mouseSent * Time.deltaTime;

        xRote -= mouseY;
        xRote = Mathf.Clamp(xRote, -90f, 90f);
        transform.localRotation = Quaternion.Euler(xRote, 0f, 0f);
        body.Rotate(Vector3.up * mouseX);
    }
}
