package com.caibi.opengl.RenderEngine;

public class RenderShaders extends Shader{
    public RenderShaders() {
        super("/Shaders/vert.glsl", "/Shaders/frag.glsl");
    }
}
